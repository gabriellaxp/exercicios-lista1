
#include<stdio.h>
#include<stdlib.h>

void main(){
    float valoremp,parc, parcead;
    float taxajuro, taxaadd;
    int qtdvezes;

    printf("\nQual e o valor do emprestimo:\t");
    scanf("%f", &valoremp);

    printf("\nDigite a Quantidade de Vezes que Sera parcelado o Emprestimo:\t");
    scanf("%d", &qtdvezes);

    printf("\nDigite a Taxa de Juros Simples:\t");
    scanf("%f", &taxajuro);

    printf("\nDigite a Taxa de Juros Adicionais:\t");
    scanf("%f", &taxaadd);

    parc =(valoremp/qtdvezes)(taxajuro/100);
    parcead=(valoremp/qtdvezes)(taxaadd/100);

    printf("\nValor sem juros adicionados - %.2f", parc);
    printf("\nValor com juros adicionados - %.2f", parcead);
}

