#include<stdio.h>
#include<stdlib.h>
void main(){
    float produtox, produtoy, produtoz;
    int qtdx, qtdy, qtdz;

    printf("\nDigite a quatidade do pruduto X:\t");
    scanf("%d", &qtdx);

    printf("\nDigite a quatidade do pruduto Y:\t");
    scanf("%d", &qtdy);

    printf("\nDigite a quatidade do pruduto Z:\t");
    scanf("%d", &qtdz);

    produtox = qtdx*10;
    produtoy = qtdy*15;
    produtoz = qtdz*20;

    printf("\nValor do produto X  %.2f", produtox);
    printf("\nValor do produto Y %.2f", produtoy);
    printf("\nValor do produto Z  %.2f", produtoz);
}
