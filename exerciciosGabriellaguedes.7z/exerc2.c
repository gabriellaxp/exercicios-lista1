#include<stdio.h>
#include<stdlib.h>
void main(){
    float notaAv, notaTrabalho, notaSim, mpond;

    printf("\nDigite a nota de sua avaliacao:\t");
    scanf("%f", &notaAv);

    printf("\nDigite a nota do trabalho:\t");
    scanf("%f", &notaTrabalho);

    printf("\nDigite a nota do simulado:\t");
    scanf("%f", &notaSim);

   mpond=(notaAv*5+notaTrabalho*3+notaSim*2)/10;

    printf("\nA sua media ponderada eh %.2f", mpond);

}
