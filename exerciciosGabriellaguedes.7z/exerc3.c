#include<stdio.h>
#include<stdlib.h>

void main()
{
    float peso1, peso2, maiorpeso, menorpeso;
    float novovalor1, novovalor2;

    printf("\n**********************MENU*********************\n");
    printf("\nO Valor do PRODUTO MENOR E DUAS VEZES A SUA QUANTIDADE DE SEU PESO E ");
    printf("\nO Valor do PRODUTO MAIS PESADO E DUAS VEZES O DO ORIGINAL QUE E O PRIMEIRO PESO");
    printf("\n**********************MENU*********************\n\n");

    printf("\nDigite o peso do primeiro produto:\t");
    scanf("%f", &peso1);

    printf("\nDigite o peso do segundo produto:\t");
    scanf("%f", &peso2);

    if(peso1>0 && peso2>0)
    {
        if(peso1>=peso2)
        {
            maiorpeso=peso1;
            menorpeso=peso2;

            printf("\nPESO 1 E MAIOR QUE PESO 2\n");

            if(peso1/2==peso2)
            {
                novovalor2=peso2*2;
                novovalor1=novovalor2*2;

                printf("\nValor do Produto 1:\t %.2f", novovalor1);
                printf("\nValor do Produto 2:\t %.2f", novovalor2);
            }else{
                novovalor2=peso2*2;
                novovalor1=(peso1*novovalor2)/peso2;

                printf("\nValor do Produto 1:\t %.2f", novovalor1);
                printf("\nValor do Produto 2:\t %.2f", novovalor2);

            }
        }
        else if(peso2>=peso1)
        {
            maiorpeso=peso2;
            menorpeso=peso1;

            printf("\nPESO 2 E MAIOR QUE PESO 1\n");

            if(peso2/2==peso1)
            {
                novovalor1=peso1*2;
                novovalor2=novovalor1*2;

                printf("\nValor do Produto 1:\t %.2f", novovalor1);
                printf("\nValor do Produto 2:\t %.2f", novovalor2);
            }
            else{
                novovalor1=peso1*2;
                novovalor2=(peso2*novovalor1)/peso1;

                printf("\nValor do Produto 1:\t %.2f", novovalor1);
                printf("\nValor do Produto 2:\t %.2f", novovalor2);
            }
        }
    }
    else
    {
        printf("\nDigite um Peso Valido !!! de preferencia maior que zero !!!");
    }

}
