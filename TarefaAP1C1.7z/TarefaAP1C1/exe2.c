/// Fazer um programa para ler 3 valores (considere que n�o ser�o informados valore iguais) e escrev�-los em ordem crescente.

#include<stdio.h>
#include<stdlib.h>

void main()
{
    int valorA, valorB, valorC;

    printf("\nDigite o Valor A:\t");
    scanf("%d", &valorA);

    printf("\nDigite o Valor B:\t");
    scanf("%d", &valorB);

    printf("\nDigite o Valor C:\t");
    scanf("%d", &valorC);


    ///se um for diferente do outro ele entra no if.
    if(valorA!=valorB || valorB != valorC || valorA!=valorC)
    {
        if(valorA>valorB && valorA>valorC && valorB>valorC)
        {
            printf("\n%d", valorC);
            printf("\n%d", valorB);
            printf("\n%d", valorA);
        }
        else if(valorB>valorA && valorB>valorC && valorA>valorC)
        {
            printf("\n%d", valorC);
            printf("\n%d", valorA);
            printf("\n%d", valorB);

        }
        else if(valorC>valorB && valorC>valorA && valorB>valorA)
        {
            printf("\n%d", valorA);
            printf("\n%d", valorB);
            printf("\n%d", valorC);
        }
        else if(valorC>valorB && valorC>valorA && valorA>valorB)
        {
            printf("\n%d", valorB);
            printf("\n%d", valorA);
            printf("\n%d", valorC);
        }
        else if(valorB>valorC && valorB>valorA && valorC>valorA)
        {
            printf("\n%d", valorA);
            printf("\n%d", valorC);
            printf("\n%d", valorB);
        }
        else if(valorC>valorB && valorC>valorA && valorA>valorB)
        {
            printf("\n%d", valorB);
            printf("\n%d", valorA);
            printf("\n%d", valorC);
        }
        else
        {
            printf("\n%d", valorB);
            printf("\n%d", valorC);
            printf("\n%d", valorA);
        }
    }
    else
    {
        printf("\nErro, Numeros Iguais !!!");
    }

}
