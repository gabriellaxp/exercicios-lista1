///Fa�a um programa em linguagem C para calcular o valor total das hospedagens na Pousada Epitaciana.
///Para realizar o c�lculo, deve ser fornecido a quantidade de di�rias (quantos dias o h�spede ficou
///hospedado), os gastos extras (quanto o h�spede gastou do frigobar do apartamento)
///e o valor do apartamento. No fechamento da conta, o funcion�rio pergunta ao h�spede de onde ele �
///e define o percentual de desconto de acordo com a tabela abaixo:
///Apresente o valor total da hospedagem, o valor do desconto e o valor a ser pago pelo cliente.(editado)

#include<stdio.h>
#include<stdlib.h>

void main()
{
        int qtdDiarias, op;
        float gastosExtras,valorAp, valorTotal;

        printf("\n**************MENU*****************\n");
        printf("\nDigite 1 - Da regiao\n");
        printf("\nDigite 2 - De outro estado\n");
        printf("\nDigite 3 - De outro pais\n");
        printf("\n**************MENU*****************\n");

        printf("\nDigite uma opcao: \t");
        scanf("%d", &op);

        printf("\nInforme os dias que o hospede ficou hospedado: \t");
        scanf("%d", &qtdDiarias);

        printf("\nInforme os gastos do frigobar do apartamento: \t");
        scanf("%f", &gastosExtras);

        printf("\nInforme o valor do apartamento: \t");
        scanf("%f", &valorAp);

        if(op == 1)
        {
            printf("\nHospede da regiao");
            valorTotal = (qtdDiarias*(gastosExtras+valorAp)) - (qtdDiarias*(gastosExtras+valorAp)*0.05);
            printf("\nO valor total com desconto:  %.2f", valorTotal);
        }
        else if(op == 2)
        {
            printf("\nDe outro estado");
            valorTotal = (qtdDiarias*(gastosExtras+valorAp)) - (qtdDiarias*(gastosExtras+valorAp)*0.07);
            printf("\nO valor total com desconto: %.2f", valorTotal);
        }
        else if(op == 3)
        {
            printf("\nDe outro pais");
            valorTotal = (qtdDiarias*(gastosExtras+valorAp)) - (qtdDiarias*(gastosExtras+valorAp)*0.1);
            printf("\nO valor total com desconto: %.2f", valorTotal);
        }
        else
        {
            printf("\nOpcao Invalida!!!");
        }
}
